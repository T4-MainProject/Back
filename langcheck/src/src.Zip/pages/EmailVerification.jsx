import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { authAPI } from '../services/api';
import NotificationModal from '../components/NotificationModal';

export default function EmailVerification() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [verificationState, setVerificationState] = useState({
    status: 'verifying', // 'verifying', 'success', 'error'
    message: '',
    title: ''
  });
  const [notification, setNotification] = useState({
    isOpen: false,
    type: 'success',
    title: '',
    message: ''
  });

  useEffect(() => {
    if (token) {
      verifyEmail(token);
    } else {
      setVerificationState({
        status: 'error',
        title: '잘못된 접근',
        message: '유효하지 않은 인증 링크입니다.'
      });
    }
  }, [token]);

  const verifyEmail = async (verificationToken) => {
    try {
      const response = await authAPI.verifyEmail(verificationToken);
      setVerificationState({
        status: 'success',
        title: '이메일 인증 완료!',
        message: '이메일 인증이 성공적으로 완료되었습니다.\n이제 로그인하실 수 있습니다.'
      });
    } catch (error) {
      console.error('이메일 인증 오류:', error);
      setVerificationState({
        status: 'error',
        title: '이메일 인증 실패',
        message: error.message || '이메일 인증 중 오류가 발생했습니다.'
      });
    }
  };

  const handleLoginRedirect = () => {
    navigate('/');
  };

  const handleResendEmail = () => {
    setNotification({
      isOpen: true,
      type: 'info',
      title: '이메일 재전송',
      message: '이메일 주소를 입력하여 인증 이메일을 재전송하세요.'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          {/* 아이콘 */}
          <div className="mx-auto flex items-center justify-center w-16 h-16 rounded-full mb-6">
            {verificationState.status === 'verifying' && (
              <svg className="animate-spin h-8 w-8 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            )}
            {verificationState.status === 'success' && (
              <div className="bg-green-100 w-full h-full flex items-center justify-center rounded-full">
                <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
            {verificationState.status === 'error' && (
              <div className="bg-red-100 w-full h-full flex items-center justify-center rounded-full">
                <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
            )}
          </div>

          {/* 제목 */}
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {verificationState.title}
          </h1>

          {/* 메시지 */}
          <p className="text-gray-600 mb-8 whitespace-pre-line">
            {verificationState.message}
          </p>

          {/* 버튼 */}
          <div className="space-y-3">
            {verificationState.status === 'success' && (
              <button
                onClick={handleLoginRedirect}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-xl font-semibold hover:bg-blue-700 transition-colors duration-200"
              >
                로그인하러 가기
              </button>
            )}
            
            {verificationState.status === 'error' && (
              <>
                <button
                  onClick={handleResendEmail}
                  className="w-full bg-blue-600 text-white py-3 px-4 rounded-xl font-semibold hover:bg-blue-700 transition-colors duration-200"
                >
                  이메일 재전송
                </button>
                <button
                  onClick={handleLoginRedirect}
                  className="w-full bg-gray-200 text-gray-800 py-3 px-4 rounded-xl font-semibold hover:bg-gray-300 transition-colors duration-200"
                >
                  홈으로 돌아가기
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 알림 모달 */}
      <NotificationModal
        isOpen={notification.isOpen}
        onClose={() => setNotification({ ...notification, isOpen: false })}
        type={notification.type}
        title={notification.title}
        message={notification.message}
      />
    </div>
  );
} 
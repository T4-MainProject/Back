// src/pages/GradingResult.jsx - 백엔드 실제 분석 결과 표시
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export default function GradingResult() {
  const location = useLocation();
  const navigate = useNavigate();
  
  // 업로드 페이지에서 전달받은 실제 분석 결과
  const analysisResult = location.state?.analysisResult;
  const uploadData = location.state?.uploadData;
  
  const [showVisualization, setShowVisualization] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [modalImageUrl, setModalImageUrl] = useState('');
  const [modalImageAlt, setModalImageAlt] = useState('');
  const [imageScale, setImageScale] = useState(1);
  const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // 분석 결과가 없으면 홈으로 리다이렉트
  useEffect(() => {
    if (!analysisResult) {
      console.log('분석 결과가 없어서 홈으로 이동합니다.');
      navigate('/');
    }
  }, [analysisResult, navigate]);

  useEffect(() => {
    console.log('🔍 GradingResult에서 받은 데이터:', {
      analysisResult,
      uploadData,
      answers: analysisResult?.answers,
      qualityAnalysis: analysisResult?.quality_analysis,
      visualization: analysisResult?.visualization
    });
  }, [analysisResult, uploadData]);

  if (!analysisResult) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">분석 결과를 불러오는 중...</p>
        </div>
      </div>
    );
  }

  // 백엔드 응답에서 실제 데이터 추출
  const answers = analysisResult.answers || [];
  const qualityAnalysis = analysisResult.quality_analysis || {};
  const statistics = qualityAnalysis.statistics || {};
  const methodDistribution = qualityAnalysis.method_distribution || {};
  const yoloStats = qualityAnalysis.yolo_only_stats || {};
  const recommendations = qualityAnalysis.recommendations || [];
  const visualization = analysisResult.visualization || {};

  // 답안별 개수 계산
  const answerCounts = answers.reduce((acc, answer) => {
    if (answer.detected_answer) {
      acc[answer.detected_answer] = (acc[answer.detected_answer] || 0) + 1;
    }
    return acc;
  }, {});

  // 신뢰도별 분류
  const highConfidenceAnswers = answers.filter(a => a.confidence > 0.7);
  const mediumConfidenceAnswers = answers.filter(a => a.confidence >= 0.3 && a.confidence <= 0.7);
  const lowConfidenceAnswers = answers.filter(a => a.confidence > 0 && a.confidence < 0.3);
  const undetectedAnswers = answers.filter(a => !a.detected_answer);

  // 방법별 통계
  const yoloSuccessCount = methodDistribution.yolo_only || 0;
  const yoloFailedCount = methodDistribution.yolo_failed || 0;
  const cropFailedCount = methodDistribution.crop_failed || 0;

  const handleBackToHome = () => {
    navigate('/');
  };

  const handleNewUpload = () => {
    navigate('/exam-upload');
  };

  // 이미지 모달 관련 함수들
  const openImageModal = (imageUrl, imageAlt) => {
    setModalImageUrl(imageUrl);
    setModalImageAlt(imageAlt);
    setIsImageModalOpen(true);
    setImageScale(1);
    setImagePosition({ x: 0, y: 0 });
  };

  const closeImageModal = () => {
    setIsImageModalOpen(false);
    setModalImageUrl('');
    setModalImageAlt('');
    setImageScale(1);
    setImagePosition({ x: 0, y: 0 });
  };

  const handleZoomIn = () => {
    setImageScale(prev => Math.min(prev + 0.2, 3));
  };

  const handleZoomOut = () => {
    setImageScale(prev => Math.max(prev - 0.2, 0.5));
  };

  const handleResetZoom = () => {
    setImageScale(1);
    setImagePosition({ x: 0, y: 0 });
  };

  const handleMouseDown = (e) => {
    if (e.button === 0 && imageScale > 1) {
      setIsDragging(true);
      setDragStart({
        x: e.clientX - imagePosition.x,
        y: e.clientY - imagePosition.y
      });
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging && imageScale > 1 && e.buttons === 1) {
      setImagePosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    } else if (isDragging && e.buttons !== 1) {
      setIsDragging(false);
    }
  };

  const handleMouseUp = (e) => {
    if (e.button === 0) {
      setIsDragging(false);
    }
  };

  const handleWheel = (e) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setImageScale(prev => Math.max(0.5, Math.min(3, prev + delta)));
  };

  // ESC 키로 모달 닫기
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isImageModalOpen) {
        closeImageModal();
      }
    };

    if (isImageModalOpen) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isImageModalOpen]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 헤더 */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={handleBackToHome}
                className="text-gray-600 hover:text-gray-800 mr-4 transition-colors duration-200"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AI 채점 결과
              </h1>
            </div>
            <button
              onClick={handleNewUpload}
              className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-2 rounded-xl font-semibold hover:shadow-lg transition-all duration-200 hover:scale-105"
            >
              새 시험지 업로드
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* 전체 요약 카드 */}
          <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-2">분석 완료!</h2>
              <p className="text-gray-600">
                {uploadData?.subject || '시험지'} • {uploadData?.grade || ''} • 
                처리시간: {analysisResult.processing_time}초
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-1">
                  {statistics.total_questions || answers.length}
                </div>
                <div className="text-gray-600">총 문제 수</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-1">
                  {statistics.detected_answers || answers.filter(a => a.detected_answer).length}
                </div>
                <div className="text-gray-600">검출된 답안</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-1">
                  {statistics.detection_rate || 0}%
                </div>
                <div className="text-gray-600">검출률</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-1">
                  {qualityAnalysis.score || 0}점
                </div>
                <div className="text-gray-600">품질 점수</div>
              </div>
            </div>
          </div>

          {/* 검출된 답안 목록 */}
          <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">📝 검출된 답안 목록</h3>
            
            {answers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {answers.map((answer, index) => (
                  <div 
                    key={index}
                    className={`p-4 rounded-2xl border-2 transition-all duration-200 hover:scale-105 ${
                      answer.detected_answer
                        ? answer.confidence > 0.7
                          ? 'bg-green-50 border-green-300 text-green-800'
                          : answer.confidence > 0.3
                          ? 'bg-yellow-50 border-yellow-300 text-yellow-800'
                          : 'bg-orange-50 border-orange-300 text-orange-800'
                        : 'bg-gray-50 border-gray-300 text-gray-600'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-lg">문제 {answer.qna_index}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        answer.priority === 'high' ? 'bg-green-100 text-green-700' :
                        answer.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        answer.priority === 'low' ? 'bg-orange-100 text-orange-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {answer.priority === 'high' ? '높음' :
                         answer.priority === 'medium' ? '보통' :
                         answer.priority === 'low' ? '낮음' : '없음'}
                      </span>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">검출된 답안:</span>
                        <span className="font-bold text-lg">
                          {answer.detected_answer || '미검출'}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm">신뢰도:</span>
                        <span className="font-medium">
                          {Math.round((answer.confidence || 0) * 100)}%
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm">방법:</span>
                        <span className="text-xs font-medium">
                          {answer.method === 'yolo_only' ? 'YOLO 검출' :
                           answer.method === 'yolo_failed' ? 'YOLO 실패' :
                           answer.method === 'crop_creation_failed' ? '크롭 실패' :
                           answer.method || '알 수 없음'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="text-gray-400 text-lg">검출된 답안이 없습니다.</div>
              </div>
            )}
          </div>

          {/* 방법별 통계 */}
          <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">📊 분석 방법별 통계</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-green-50 rounded-2xl">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="text-3xl font-bold text-green-600 mb-1">{yoloSuccessCount}</div>
                <div className="text-green-700 font-medium">YOLO 성공</div>
              </div>

              <div className="text-center p-6 bg-red-50 rounded-2xl">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div className="text-3xl font-bold text-red-600 mb-1">{yoloFailedCount}</div>
                <div className="text-red-700 font-medium">YOLO 실패</div>
              </div>

              <div className="text-center p-6 bg-yellow-50 rounded-2xl">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L5.232 15.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                </div>
                <div className="text-3xl font-bold text-yellow-600 mb-1">{cropFailedCount}</div>
                <div className="text-yellow-700 font-medium">크롭 실패</div>
              </div>
            </div>
          </div>

          {/* 시각화 이미지 */}
          {visualization.available && visualization.base64 && (
            <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-800">🎨 검출 결과 시각화</h3>
                <button
                  onClick={() => setShowVisualization(!showVisualization)}
                  className="bg-blue-500 text-white px-4 py-2 rounded-xl font-medium hover:bg-blue-600 transition-colors duration-200"
                >
                  {showVisualization ? '숨기기' : '보기'}
                </button>
              </div>
              
              {showVisualization && (
                <div className="text-center">
                  <div 
                    className="cursor-pointer relative group inline-block"
                    onClick={() => openImageModal(`data:image/jpeg;base64,${visualization.base64}`, '검출 결과 시각화')}
                  >
                    <img
                      src={`data:image/jpeg;base64,${visualization.base64}`}
                      alt="검출 결과 시각화"
                      className="max-w-full h-auto rounded-2xl shadow-lg transition-transform duration-200 group-hover:scale-105"
                    />
                    {/* 확대 아이콘 오버레이 */}
                    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200 rounded-2xl">
                      <div className="bg-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                        </svg>
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 mt-4">클릭하면 확대해서 볼 수 있습니다</p>
                </div>
              )}
            </div>
          )}

          {/* AI 추천사항 */}
          {recommendations.length > 0 && (
            <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">💡 AI 추천사항</h3>
              
              <div className="space-y-4">
                {recommendations.map((recommendation, index) => (
                  <div key={index} className="p-4 bg-blue-50 rounded-2xl border border-blue-200">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <span className="text-white text-sm font-bold">{index + 1}</span>
                      </div>
                      <div className="text-blue-800">{recommendation}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 답안 분포 */}
          {Object.keys(answerCounts).length > 0 && (
            <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">📈 답안 분포</h3>
              
              <div className="grid grid-cols-5 gap-4">
                {['①', '②', '③', '④', '⑤'].map((option, index) => (
                  <div key={option} className="text-center p-4 bg-gray-50 rounded-2xl">
                    <div className="text-2xl font-bold text-gray-800 mb-2">{option}</div>
                    <div className="text-3xl font-bold text-blue-600 mb-1">
                      {answerCounts[option] || 0}
                    </div>
                    <div className="text-gray-600 text-sm">문제</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 품질 분석 */}
          <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">⭐ 품질 분석</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-purple-600 mb-2">
                  {qualityAnalysis.score || 0}점
                </div>
                <div className="text-gray-600 mb-4">전체 품질 점수</div>
                <div className={`inline-block px-4 py-2 rounded-full font-medium ${
                  (qualityAnalysis.score || 0) > 90 ? 'bg-green-100 text-green-700' :
                  (qualityAnalysis.score || 0) > 70 ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {qualityAnalysis.grade || '평가 중'}
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">고신뢰도 검출</span>
                  <span className="font-bold text-green-600">{statistics.high_confidence || 0}개</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">중신뢰도 검출</span>
                  <span className="font-bold text-yellow-600">{statistics.medium_confidence || 0}개</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">저신뢰도 검출</span>
                  <span className="font-bold text-orange-600">{statistics.low_confidence || 0}개</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">YOLO 성공률</span>
                  <span className="font-bold text-blue-600">{yoloStats.success_rate || 0}%</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 🖼️ 이미지 확대/축소 모달 */}
      {isImageModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
          <div className="relative w-full h-full flex items-center justify-center">
            {/* 모달 헤더 */}
            <div className="absolute top-4 left-4 right-4 z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <h3 className="text-white text-lg font-bold">{modalImageAlt}</h3>
                  <div className="text-white text-sm">
                    확대/축소: {Math.round(imageScale * 100)}%
                  </div>
                </div>
                <button
                  onClick={closeImageModal}
                  className="text-white hover:text-gray-300 transition-colors duration-200"
                >
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            {/* 모달 컨트롤 버튼 */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-10">
              <div className="flex items-center space-x-2 bg-black bg-opacity-60 rounded-full px-4 py-2">
                <button
                  onClick={handleZoomOut}
                  className="text-white hover:text-gray-300 transition-colors duration-200 p-2"
                  title="축소 (Ctrl + -)"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                  </svg>
                </button>
                <button
                  onClick={handleResetZoom}
                  className="text-white hover:text-gray-300 transition-colors duration-200 p-2"
                  title="원본 크기"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                  </svg>
                </button>
                <button
                  onClick={handleZoomIn}
                  className="text-white hover:text-gray-300 transition-colors duration-200 p-2"
                  title="확대 (Ctrl + +)"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </button>
              </div>
            </div>

            {/* 이미지 컨테이너 */}
            <div 
              className="w-full h-full flex items-center justify-center overflow-hidden"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onWheel={handleWheel}
              style={{ cursor: imageScale > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default' }}
            >
              <img
                src={modalImageUrl}
                alt={modalImageAlt}
                className="max-w-none select-none"
                style={{
                  transform: `scale(${imageScale}) translate(${imagePosition.x / imageScale}px, ${imagePosition.y / imageScale}px)`,
                  transition: isDragging ? 'none' : 'transform 0.2s ease-out'
                }}
                onError={(e) => {
                  e.target.src = '/image.png';
                  console.warn('모달 이미지 로딩 실패:', modalImageUrl);
                }}
              />
            </div>

            {/* 배경 클릭 시 모달 닫기 */}
            <div 
              className="absolute inset-0 -z-10"
              onClick={closeImageModal}
            />

            {/* ESC 키 안내 */}
            <div className="absolute top-4 right-20 text-white text-sm opacity-70">
              ESC 키로 닫기
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
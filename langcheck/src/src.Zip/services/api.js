// 현재 호스트에 따라 API URL 동적 설정
const getAPIBaseURL = () => {
  const hostname = window.location.hostname;
  const port = window.location.port;
  
  console.log('Current hostname:', hostname);  // 디버깅용
  console.log('Current port:', port);  // 디버깅용
  
  if (hostname === '192.168.0.24') {
    console.log('Using network API URL');  // 디버깅용
    return 'http://192.168.0.24:8000/api/v1';
  }
  console.log('Using localhost API URL');  // 디버깅용
  return 'http://localhost:8000/api/v1';
};

const API_BASE_URL = getAPIBaseURL();
console.log('Final API_BASE_URL:', API_BASE_URL);  // 디버깅용

// HTTP 요청 헬퍼 함수
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  const token = localStorage.getItem('authToken');
  
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
    },
  };

  try {
    const response = await fetch(url, {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...options.headers,
      },
    });

    if (!response.ok) {
      let error;
      try {
        const errorData = await response.json();
        error = errorData.detail || errorData.message || `HTTP error! status: ${response.status}`;
      } catch {
        error = await response.text() || `HTTP error! status: ${response.status}`;
      }
      throw new Error(error);
    }

    return response.json();
  } catch (error) {
    // 네트워크 연결 오류 등
    if (error.name === 'TypeError' || error.message.includes('fetch')) {
      throw new Error('서버에 연결할 수 없습니다. 백엔드 서버가 실행 중인지 확인해주세요.');
    }
    throw error;
  }
};

// 인증 관련 API
export const authAPI = {
  // 회원가입
  register: async (userData) => {
    return await apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },

  // 로그인
  login: async (email, password) => {
    const response = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    if (response.access_token) {
      localStorage.setItem('authToken', response.access_token);
      localStorage.setItem('user', JSON.stringify(response.user));
    }
    
    return response;
  },

  // 이메일 인증
  verifyEmail: async (token) => {
    return await apiRequest(`/auth/verify-email/${token}`, {
      method: 'GET',
    });
  },

  // 이메일 인증 재전송
  resendVerification: async (email) => {
    return await apiRequest('/auth/resend-verification', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  // 임시 비밀번호 발송
  sendTemporaryPassword: async (email) => {
    return await apiRequest('/auth/send-temporary-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  // 비밀번호 찾기
  forgotPassword: async (email) => {
    return await apiRequest('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  // 비밀번호 재설정
  resetPassword: async (token, newPassword) => {
    return await apiRequest('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, new_password: newPassword }),
    });
  },

  // 비밀번호 재설정 (6자리 코드 방식)
  resetPasswordWithCode: async (email, code, newPassword, confirmPassword) => {
    return await apiRequest('/auth/reset-password-with-code', {
      method: 'POST',
      body: JSON.stringify({ 
        email, 
        code, 
        new_password: newPassword,
        new_password_confirm: confirmPassword
      }),
    });
  },

  // 로그아웃
  logout: () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },
};

// 사용자 관련 API
export const userAPI = {
  // 프로필 조회
  getProfile: async () => {
    return await apiRequest('/users/me');
  },

  // 프로필 업데이트
  updateProfile: async (userData) => {
    return await apiRequest('/users/me', {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  },

  // 비밀번호 변경
  changePassword: async (currentPassword, newPassword) => {
    return await apiRequest('/users/change-password', {
      method: 'POST',
      body: JSON.stringify({
        current_password: currentPassword,
        new_password: newPassword,
      }),
    });
  },

  // 계정 삭제
  deleteAccount: async () => {
    return await apiRequest('/users/me', {
      method: 'DELETE',
    });
  },
};

// 로컬 저장소 유틸리티 함수들 (기존 코드와의 호환성을 위해)
export const storageUtils = {
  // 사용자 정보 저장
  saveUserToStorage: (user, token) => {
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify(user));
  },

  // 사용자 정보 조회
  getUserFromStorage: () => {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },

  // 사용자 정보 삭제
  removeUserFromStorage: () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },

  // 이메일 존재 여부 확인 (백엔드에서 처리할 예정이므로 임시)
  checkEmailExists: async (email) => {
    try {
      // 실제로는 별도의 API 엔드포인트가 필요하지만, 
      // 지금은 로그인 시도로 확인
      await authAPI.login(email, 'dummy');
      return true;
    } catch (error) {
      return false;
    }
  },

  // 비밀번호 업데이트 (resetPassword와 동일)
  updateUserPassword: async (email, newPassword, token) => {
    return await authAPI.resetPassword(token, newPassword);
  },

  // 사용자 등록 (회원가입과 동일)
  registerUser: async (userData) => {
    return await authAPI.register(userData);
  },

  // 로그인 검증 (로그인과 동일)
  validateLogin: async (email, password) => {
    return await authAPI.login(email, password);
  },
};

export default {
  authAPI,
  userAPI,
  storageUtils,
}; 